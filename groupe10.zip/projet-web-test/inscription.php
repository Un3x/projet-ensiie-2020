<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Inscription</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="Inscription.css">
</head>
<body>
	?>
	<h1>Bienvenue chez Football Manager</h1>
	<h2>Remplissez les informations ci-dessous pour vous inscrire</h2>

	<form method="post" action="inscription.php">
		<label for=nom>Nom :</label>
		<input type="text" name="nom">
		<label for=prenom>Prenom :</label>
		<input type="text" name="prenom">
		<label for="pseudo">Pseudo :</label>
		<input type="text" name="pseudo">
		<label for="password">Mot de passe : </label>
		<input type="password" name="password" id="password" onfocusout="verifier_password()">
		<label for="confirm_password">Confirmer le mot de passe :</label>
		<input type="password" name="confirm_password" id="confirm_password" onfocusout="verifier_password()">
		<p id="error_password" hidden='true'>Les mots de passe ne correspondent pas</p>
		<label for="rapport">Lien avec le football</label>
		<select name="rapport" id="rapport" onfocusout="show()">
			<option></option>
			<option>Supporter</option>
			<option>Joueur</option>
			<option>Coach</option>
			<option>Autre</option>
		</select>

		<div id="for_coach" hidden>
			<label for="equipe">Indiquez l'équipe avec laquelle vous travaillez</label>
			<select name ="equipe">
				<option>Amiens</option>
				<option>Angers</option>
				<option>Bordeaux</option>
				<option>Brest</option>
				<option>Dijon</option>
				<option>Lille</option>
				<option>Lyon</option>
				<option>Marseille</option>
				<option>Metz</option>
				<option>Monaco</option>
				<option>Montpellier</option>
				<option>Nantes</option>
				<option>Nice</option>
				<option>Nîmes</option>
				<option>PSG</option>
				<option>Reims</option>
				<option>Rennes</option>
				<option>Saint-Etienne</option>
				<option>Strasbourg</option>
				<option>Toulouse</option>
			</select>
			<br/>
		</div>
		<div id="for_joueur" hidden>
			<label for="date_naissance">Date de naissance :</label>
			<input type="date" name="date_naissance">

			<label for="poste">Poste :</label>
			<select name="poste">
				<option>Gardien</option>
				<option>Milieu offensif</option>
				<option>Milieu défensif</option>
				<option>Attaquant</option>
				<option>Défenseur</option>
			</select>
			<label for="prix">Prix auquel un club peut vous acheter (en €)</label>
			<input type="number" name="prix">
		</div>

		<input type="submit" name="inscription" id="inscription"  value="S'inscrire" style="color:black;">
	</form>

	<?php
			if(isset($_POST['nom']) AND isset($_POST['prenom']) AND $_POST['rapport']!="" AND $_POST['pseudo']!="" AND $_POST['password']){
					try{
						$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
					}
					catch(Exception $e){
					        die('Erreur : '.$e->getMessage());
					}

					$existant = $bdd->prepare('SELECT nom,prenom,pseudo FROM personne WHERE nom= ? AND prenom=?');
					$existant->execute(array(htmlspecialchars($_POST['nom']), htmlspecialchars($_POST['prenom'])));
					$exist = $existant->fetch();

					$existant_coach = $bdd->prepare('SELECT equipe FROM organisateur WHERE equipe=?');
					$existant_coach->execute(array(htmlspecialchars($_POST['equipe'])));
					$exist_coach = $existant_coach->fetch();

					if($exist['nom']=="" AND $exist['prenom']==""){

						if (htmlspecialchars($_POST['rapport'])=="Coach") {
													$existant_coach = $bdd->prepare('SELECT equipe FROM organisateur WHERE equipe=?');
													$existant_coach->execute(array(htmlspecialchars($_POST['equipe'])));
													$exist_coach = $existant_coach->fetch();
													if($existant_coach==""){
														$existant_pseudo = $bdd->prepare('SELECT pseudo FROM personne WHERE pseudo=?');
														$existant_pseudo->execute(array(htmlspecialchars($_POST['pseudo'])));
														$exist_pseudo = $existant_pseudo->fetch();
									
														if($exist_pseudo['pseudo']==""){
																$req = $bdd->prepare('INSERT INTO personne(nom, prenom,pseudo,password) VALUES(:nom, :prenom,:pseudo,:password)');
																$req->execute(array(
																'nom' => htmlspecialchars($_POST['nom']),
																'prenom' => htmlspecialchars($_POST['prenom']),
																'pseudo'=>htmlspecialchars($_POST['pseudo']),
																'password'=>htmlspecialchars($_POST['password'])
																));
																$id=$bdd->lastInsertId();
																$req_j = $bdd->prepare('INSERT INTO organisateur(id, equipe) VALUES(:id,:equipe)');
																$req_j->execute(array(
																'id' => $id,
																'equipe' => htmlspecialchars($_POST['equipe'])
																));
														}
												}

												else{
														echo "<p style='text-align:center;color:white'>Cette équipe possède déjà un coach</p>";
													}

											}

							else{
							#vérifie s'il n'y a pas déjà ce pseudo
							$existant_pseudo = $bdd->prepare('SELECT pseudo FROM personne WHERE pseudo=?');
							$existant_pseudo->execute(array(htmlspecialchars($_POST['pseudo'])));
							$exist_pseudo = $existant_pseudo->fetch();
							
											if($exist_pseudo['pseudo']==""){

											$req = $bdd->prepare('INSERT INTO personne(nom, prenom,pseudo,password) VALUES(:nom, :prenom,:pseudo,:password)');
											$req->execute(array(
											'nom' => htmlspecialchars($_POST['nom']),
											'prenom' => htmlspecialchars($_POST['prenom']),
											'pseudo'=>htmlspecialchars($_POST['pseudo']),
											'password'=>htmlspecialchars($_POST['password'])
											));

											$id=$bdd->lastInsertId();

											if(htmlspecialchars($_POST['rapport'])=="Joueur"){
													$req_j = $bdd->prepare('INSERT INTO joueur(id,poste, equipe) VALUES(:id, :poste,:equipe,:prix)');
													$req_j->execute(array(
													'id' => $id,
													'poste' => htmlspecialchars($_POST['poste']),
													'equipe' => htmlspecialchars($_POST['equipe']),
													'prix'=>htmlspecialchars($_POST['prix'])
													));
											}

											echo "Votre inscription a bien été prise en compte<br/>";
											echo "<a href='index.php'>Vous pouvez retourner à l'accueil pour vous connecter</a>";
										}
						}
					}
						else{
								echo "Veuillez entrer un nouvel utilisateur";
							}
			}
			else{
				echo "<p style='color:white;text-align:center;'>Veuillez remplir tous les champs</p>";
			}
	?>

<script type="text/javascript">

	var password=document.getElementById('password');
	var confirm_password=document.getElementById('confirm_password');
	var error_password = document.getElementById('error_password');
	var inscription = document.getElementById('inscription');

	function verifier_password(){
		if(password.value!=confirm_password.value){
			error_password.removeAttribute('hidden');
			inscription.setAttribute('disabled','true')
		}
		else{
			error_password.setAttribute('hidden','true');
			inscription.removeAttribute('disabled');
		}
	}

	var rapport  = document.getElementById('rapport');
	var joueur = document.getElementById('for_joueur');
	var coach = document.getElementById('for_coach');
	function show(){
		if(rapport.value == "Joueur"){
			joueur.removeAttribute('hidden');
			coach.removeAttribute('hidden');
		}
		else if(rapport.value=="Coach"){
			joueur.setAttribute('hidden','true');
			coach.removeAttribute('hidden');
		}
		else if (rapport.value==""){
			coach.setAttribute('hidden','true');
			joueur.setAttribute('hidden','true');
			alert('Veuillez choisir une catégorie');
		}
		else{
			joueur.setAttribute('hidden','true');
			coach.setAttribute('hidden','true');
		}
	}

</script>

</body>
</html>