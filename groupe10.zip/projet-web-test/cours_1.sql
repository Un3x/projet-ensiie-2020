-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 11 mai 2020 à 13:11
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cours`
--

-- --------------------------------------------------------

--
-- Structure de la table `calendrier2`
--

DROP TABLE IF EXISTS `calendrier2`;
CREATE TABLE IF NOT EXISTS `calendrier2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dates` date NOT NULL,
  `nom` varchar(1000) NOT NULL,
  `heure` varchar(255) DEFAULT NULL,
  `id_organisateur` int(11) DEFAULT NULL,
  `lieu` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `calendrier2`
--

INSERT INTO `calendrier2` (`id`, `dates`, `nom`, `heure`, `id_organisateur`, `lieu`) VALUES
(3, '2020-05-05', 'Match de foot', '8h-10h', 4, 'Paris');

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

DROP TABLE IF EXISTS `joueur`;
CREATE TABLE IF NOT EXISTS `joueur` (
  `id` int(11) NOT NULL,
  `poste` varchar(255) NOT NULL,
  `equipe` varchar(255) NOT NULL,
  `prix` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `joueur`
--

INSERT INTO `joueur` (`id`, `poste`, `equipe`, `prix`) VALUES
(14, 'Attaquant', 'Dijon', 1000),
(20, 'défenseur', 'Strasbourg', 1000),
(21, 'Milieu offensif', 'Lille', 1500),
(22, 'Défenseur', 'PSG', 2000),
(23, 'Attaquant', 'Bordeaux', 5000),
(24, 'Défenseur', 'Montpellier', 500),
(25, 'Attaquant', 'PSG', 20000),
(26, 'Milieu défensif', 'Toulouse', 800),
(27, 'Attaquant', 'PSG', 10000);

-- --------------------------------------------------------

--
-- Structure de la table `organisateur`
--

DROP TABLE IF EXISTS `organisateur`;
CREATE TABLE IF NOT EXISTS `organisateur` (
  `id` int(11) NOT NULL,
  `equipe` varchar(255) NOT NULL,
  `budget` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `organisateur`
--

INSERT INTO `organisateur` (`id`, `equipe`, `budget`) VALUES
(4, 'ENSIIE', 9994600),
(29, 'Lille', 500000),
(28, 'PSG', 60000000),
(30, 'Nantes', 800000),
(34, 'Lyon', 800000);

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

DROP TABLE IF EXISTS `personne`;
CREATE TABLE IF NOT EXISTS `personne` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `personne`
--

INSERT INTO `personne` (`id`, `nom`, `prenom`, `pseudo`, `password`) VALUES
(4, 'Charnoz', 'Paul', 'charnoz', 'paul'),
(20, 'Aaneba', 'Ismael', 'Ismael', 'Aaneba'),
(14, 'Pascalet', 'Antoine', 'pascalet', 'antoine'),
(24, 'Hilton', 'Vitorino', 'Vitorino', 'Hilton'),
(21, 'André', 'Benjamin', 'Benjamin', 'André'),
(22, 'Bakker', 'Mitchel', 'Mitchel', 'Bakker'),
(23, 'Briand', 'Jimmy', 'Jimmy', 'Briand'),
(25, 'Neymar', 'Junior', 'Junior', 'Neymar'),
(26, 'Makengo', 'Jean-Victor', 'Jean-Victor', 'Makengo'),
(27, 'Ibrahimovic', 'Zlatan', 'Zlatan', 'Ibrahimovic'),
(28, 'Tuchel', 'Thomas', 'Thomas', 'Tuchel'),
(29, 'Galtier', 'Christophe', 'Christophe', 'Galtier'),
(30, 'Christian', 'Gourcuff', 'Christian', 'Gourcuff'),
(34, 'Toya', 'Monsieur', 'toya', 'toya');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
