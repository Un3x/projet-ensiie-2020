<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Mercato</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="mercato.css">
</head>
<body>


<?php
	include('menu.php');
	try{
		$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
	}
	catch(Exception $e){
	        die('Erreur : '.$e->getMessage());
	}

	$id_achat = $bdd->prepare('SELECT * FROM organisateur JOIN personne ON personne.id=organisateur.id WHERE personne.nom=? AND personne.prenom=?');
	$id_achat-> execute(array($_SESSION['nom'],$_SESSION['prenom']));
	$donnees_achat=$id_achat->fetch();
	if($donnees_achat['id']==""){
			echo "<h2>Vous n'êtes pas coach, vous ne pouvez pas acheter de joueurs.</h2>";
	}
	else{
		echo "<h1>Mercato</h1>
		<h2>Profitez de cet onglet pour vous constituer une équipe !</h2>
		<h2>Vous pouvez ici acheter de nouveaux joueurs.</h2>
		<form method='post' action='mercato.php'>
	<label for='joueur'>Choisissez un joueur que vous voulez acheter</label>
	<select name='joueur'>";

	$reponse_joueur  = $bdd->prepare( 'SELECT * FROM joueur JOIN personne ON personne.id=joueur.id WHERE joueur.equipe!=?');
	$reponse_joueur  -> execute(array($donnees_achat['equipe']));

    while ($donnees_joueur = $reponse_joueur->fetch()){
        echo '<option value='.$donnees_joueur['id'].'>'.htmlspecialchars($donnees_joueur['prenom']).' '.$donnees_joueur['nom'].'</option>';
    }
    $reponse_joueur->closeCursor();
	echo "</select>
	<input type ='submit' value='Afficher la description' name='afficher'>
	<input type='submit' value='Acheter' name='acheter'>
	</form>";
	$prix_joueur = $bdd->prepare('SELECT * FROM joueur JOIN personne ON personne.id=joueur.id WHERE joueur.id=?');
	if(isset($_POST['joueur'])){
		$prix_joueur-> execute(array($_POST['joueur']));
		$donnees_prix=$prix_joueur->fetch();
		echo "<p>Poste : ".$donnees_prix['poste']."<br>
		Equipe actuelle : ".$donnees_prix['equipe']."<br>
		Prix : ".$donnees_prix['prix']."</p>";

		if(isset($_POST['acheter'])){
			$budget= $bdd->prepare('SELECT * FROM organisateur JOIN personne ON personne.id=organisateur.id WHERE personne.nom=? AND personne.prenom=?');
			$budget-> execute(array($_SESSION['nom'],$_SESSION['prenom']));
			$donnees_budget=$budget->fetch();
		if($donnees_prix>0 AND $donnees_budget['budget']-$donnees_prix['prix']>=0){
				$new_budget=$donnees_budget['budget']-$donnees_prix['prix'];
				$nouveau_budget= $bdd->prepare('UPDATE organisateur set budget=? where organisateur.id=?');
				$nouveau_budget-> execute(array($new_budget,$donnees_budget['id']));
				$nouvelle_equipe= $bdd->prepare('UPDATE joueur set equipe=? where joueur.id=?');
				$nouvelle_equipe-> execute(array($donnees_budget['equipe'],$donnees_prix['id']));
				echo "<p>Achat bien effectué !</p>";
		}
		else{
			echo "<p>Vous n'avez pas assez d'argent pour acheter ce joueur</p>";
		}
		} 


	}
	else{
		echo '<p>Pas de joueur sélectionné</p>';
	}
	}

include("pieds.php");

?>

</body>
</html>
