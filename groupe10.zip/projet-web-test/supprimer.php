<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Supprimer le compte</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


	<form action="supprimer.php" method="post" style="text-align: center;">
		<label for="oui">Etes-vous sûr(e) de vouloir supprimer votre compte ?</label>
		<input type="submit" name="oui" value="Oui">
		<input type="submit" name="non" value="Non">
	</form>

<?php
	if(isset($_POST['oui'])){
		try{
			$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
		}
		catch(Exception $e){
		        die('Erreur : '.$e->getMessage());
		}
		$existant = $bdd->prepare('SELECT * FROM personne WHERE nom= ? AND prenom=?');
		$existant->execute(array(htmlspecialchars($_SESSION['nom']), htmlspecialchars($_SESSION['prenom'])));
		$exist = $existant->fetch();


		$supprimer = $bdd->prepare('DELETE FROM personne WHERE id= ?');
		$supprimer->execute(array(htmlspecialchars($exist['id'])));


		$supprimer_coach=$bdd->prepare('DELETE FROM organisateur WHERE id= ?');
		$supprimer_coach->execute(array(htmlspecialchars($exist['id'])));

		header('Location:index.php');

	}
	if(isset($_POST['non'])){
		header('Location:index2.php');
	}
?>

</body>
</html>