
	<?php

	$jour=date('d');
	$mois=date('m');
	$annee=date('Y');
	include('cible.php');

      echo "<nav><ul>
        <li><a href='index2.php' id='index'>Accueil</a></li>
        <li><a href='index_calendrier.php' id='calendrier'>Calendrier</a></li>
        <li><a href='mercato.php' id='mercato'>Mercato</a></li>
        <li><a href='organiser_une_rencontre.php?date=".$annee."-".$mois."-".$jour."' id='organiser'>Organiser une rencontre</a></li>
      </ul></nav>";
      	?>


<script type="text/javascript">
var index=document.getElementById('index');
var calendrier=document.getElementById('calendrier');
var mercato=document.getElementById('mercato');
var organiser = document.getElementById('organiser');


var urlcourante = document.location.href; 
	//On supprime l'éventuel dernier slash de l'URL
var urlcourante = urlcourante.replace(/\/$/, "");
// Gardons dans la variable queue_url uniquement la portion derrière le dernier slash de urlcourante
queue_url = urlcourante.substring (urlcourante.lastIndexOf( "/" )+1 );

if(queue_url=='index.php'){
	index.style.textDecoration = 'underline';
}
if(queue_url=='index_calendrier.php'){
	calendrier.style.textDecoration = 'underline';
}
if(queue_url=='mercato.php'){
	mercato.style.textDecoration = 'underline';
}
if(queue_url.search('organiser_une_rencontre.php')!=-1){
	organiser.style.textDecoration = 'underline';
}



</script>