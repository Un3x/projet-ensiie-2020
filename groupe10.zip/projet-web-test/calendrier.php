<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="calendrier.css">
	<meta name="viewport" content="width=device-width, height=device-height" />
	<title>Calendrier</title>
</head>
<body>

	<?php
	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
	}
	catch(Exception $e)
	{
	        die('Erreur : '.$e->getMessage());
	}
	$calendrier = $bdd->query('SELECT * FROM calendrier');
	$donnees=$calendrier->fetch();
	
		function printEvent($jour,$heure){
			$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
			$calendrier = $bdd->prepare('SELECT * FROM calendrier WHERE jour=? AND heure=?');
			$calendrier->execute(array($jour, $heure));
			$donnees=$calendrier->fetch();
			echo $donnees['nom'];
		}
	?>


	<table >
		<tr >
			<td></td>
			<td>Lundi</td>
			<td>Mardi</td>
			<td>Mercredi</td>
			<td>Jeudi</td>
			<td>Vendredi</td>
			<td>Samedi</td>
			<td>Dimanche</td>
		</tr>
		<tr class=1>
			<td>8h-9h</td>
			<td><div class="lundi"> <?php printEvent("Lundi","8h-9h"); ?>  </div></td>
			<td><div id ="mardi8"><?php printEvent("Mardi","8h-9h");  ?></div></td>
			<td><div id ="mercredi8"><?php printEvent("Mercredi","8h-9h"); ?></div></td>
			<td><div id ="jeudi8"><?php  printEvent("Jeudi","8h-9h"); ?></div></td>
			<td><div id ="vendredi8"><?php  printEvent("Vendredi","8h-9h"); ?></div></td>
			<td><div id ="samedi8"><?php  printEvent("Samedi","8h-9h"); ?></div></td>
			<td><div id ="dimanche8"><?php  printEvent("Dimanche","8h-9h"); ?></div></td>
		</tr>
		<tr class=2>
			<td>9h-10h</td>
			<td><div id ="lundi9"><?php  printEvent("Lundi","9h-10h"); ?></div></td>
			<td><div id ="mardi9"><?php  printEvent("Mardi","9h-10h"); ?></div></td>
			<td><div id ="mercredi9"><?php  printEvent("Mercredi","9h-10h"); ?></div></td>
			<td><div id ="jeudi9"><?php  printEvent("Jeudi","9h-10h"); ?></div></td>
			<td><div id ="vendredi9"><?php  printEvent("Vendredi","9h-10h"); ?></div></td>
			<td><div id ="samedi9"><?php  printEvent("Samedi","9h-10h"); ?></div></td>
			<td><div id ="dimanche9"><?php  printEvent("Dimanche","9h-10h"); ?></div></td>
		</tr>
		<tr class=3>
			<td>10h-11h</td>
			<td><div id ="lundi10"><?php  printEvent("Lundi","10h-11h"); ?></div></td>
			<td><div id ="mardo10"><?php  printEvent("Mardi","10h-11h"); ?></div></td>
			<td><div id ="mercredi10"><?php  printEvent("Mercredi","10h-11h"); ?></div></td>
			<td><div id ="jeudi10"><?php  printEvent("Jeudi","10h-11h"); ?></div></td>
			<td><div id ="vendredi10"><?php  printEvent("Vendredi","10h-11h"); ?></div></td>
			<td><div id ="samedi10"><?php  printEvent("Samedi","10h-11h"); ?></div></td>
			<td><div id ="dimanche10"><?php  printEvent("Dimanche","10h-11h"); ?></div></td>
		</tr>
		<tr class="hello">
			<td>11h-12h</td>
			<td><div id ="lundi11"><?php  printEvent("Lundi","11h-12h"); ?></div></td>
			<td><div id ="mardo11"><?php  printEvent("Mardi","11h-12h"); ?></div></td>
			<td><div id ="mercredi11"><?php  printEvent("Mercredi","11h-12h"); ?></div></td>
			<td><div id ="jeudi11"><?php  printEvent("Jeudi","11h-12h"); ?></div></td>
			<td><div id ="vendredi11"><?php  printEvent("Vendredi","11h-12h"); ?></div></td>
			<td><div id ="samedi11"><?php  printEvent("Samedi","11h-12h"); ?></div></td>
			<td><div id ="dimanche11"><?php  printEvent("Dimanche","11h-12h"); ?></div></td>
		</tr>
	</table>

	<form method="post"  action="calendrier.php">
		<select name="jour" id="jour">
			<option>Lundi</option>
			<option>Mardi</option>
			<option>Mercredi</option>
			<option>Jeudi</option>
			<option>Vendredi</option>
			<option>Samedi</option>
			<option>Dimanche</option>
		</select>
		<select name="hours" id="hours" >
			<option>8h-10h</option>
			<option>10h-12h</option>
			<option>12h-14h</option>
			<option>14h-16h</option>
			<option>16h-18h</option>
			<option>18h-20h</option>
			<option>20h-23h</option>
		</select>
		<label for="event">Quel événement voulez-vous ajouter au calendrier ?</label>
		<input type="text" name="event" id="event">

	<input type="submit" name="submit" value="Ajouter au calendrier" id="ajouter">
</form>



<?php 

	if(isset($_POST['jour']) AND isset($_POST['hours']) AND isset($_POST['event'])) {

			$req = $bdd->prepare('SELECT * FROM calendrier WHERE jour = ? AND heure = ?');
			$req->execute(array($_POST['jour'], $_POST['hours']));

			$donnees = $req -> fetch();


	if($donnees['nom']==NULL){
				$request = $bdd->prepare('INSERT INTO calendrier(jour, heure, nom) VALUES( :jour, :heure, :nom)');
				$request->execute(array(
				'nom' => $_POST['event'],
				'heure' => $_POST['hours'],
				'jour' => $_POST['jour']
				));
				header('Location: calendrier.php');
			}
			else{
				echo 'Un événement est déjà réservé à cette date';
				echo 'Ici : '.$donnees['nom'].' ';
			}

}
		else{
			echo 'Veuillez remplir tous les champs';
		}

		?>








<script type="text/javascript">

	const event = document.getElementById('event'); 
	const ajouter = document.getElementById('ajouter');
	const jour = document.getElementById('jour');
	const hours = document.getElementById('hours');
	var horaires = document.getElementsByClassName("jour_semaine_8");
	//const lundi8 = jour_semaine[0].children;

	ajouter.addEventListener('submit',function(){
		horaires = document.getElementsByClassName(hours.value);
		if(horaires[0].children[jour.value].textContent==""){
		horaires[0].children[jour.value].textContent = event.value;
	}
	else{
		alert("un événement est déjà réservé à cette date");
	}
	});
</script>


</body>
</html>

