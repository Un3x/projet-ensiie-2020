<?php
session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Football Manager - Accueil</title>
    <meta charset="utf-8">
    
    <!-- import the webpage's stylesheet -->
    <link rel="stylesheet" href="style.css">
    
  </head>
  
  
  <body>    
    <?php include("menu.php");
    echo "<span style='color:white;text-decoration:none;'>Connecté en tant que ".$_SESSION['prenom']." ".$_SESSION['nom']."</span><br>
    <a href='supprimer.php' style='color:white;'>supprimez le compte</a>";?>
    <header id="header">
        <h1>Football Manager 2020</h1>
    </header>
    <?php include("formulaire.php"); ?>
    <div id="conteneur">

      <div class="element">
        <h1 class="titres">Actualités</h1>
        <p>Les joueuses américaines ont fait appel de la décision de justice du 1er mai et demandent désormais à être payées plus que l'équipe masculine des USA. Selon le Wall Street Journal, l’équipe féminine américaine a rapporté plus que l’équipe masculine entre 2016 et 2018.</p>
        <p>Guéri du Covid-19, Paulo Dybala a repris l’entraînement avec la Juventus.</p>
        <p>Les clubs de Premier League voteront lundi concernant une reprise du championnat sur terrain neutre.<br/>
        Les 6 derniers (Brighton, WH, Watford, Bournemouth, Aston Villa et Norwich) refusent parce-qu'ils considèrent important (pour leur maintien) de jouer dans leur stade.</p>
        <p>Il y a 24 ans jour pour jour, le PSG remportait la Coupes de coupes face au Rapid Vienne.</p>
        <p>Paolo Maldini : « Il faut essayer d'aller sur le terrain, ce serait un désastre à tous points de vue, d'abord économique. Nous devons essayer. La France, à mon avis, a fait une erreur. »
        </p>

      </div>

       <?php include("side.php"); ?>
      

      
    </div>
     
    <?php include("pieds.php"); ?>
    
    
  </body>
</html>
