<?php
session_start();
$mois=date('m');
$annee=date('Y');
include('opti.php');
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="index_calendrier.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Calendrier</title>
</head>
<body>

	<div>
		<img id="prev" src="img/fg.png" height="40px" width="40px" style="float: left;">
		<img id="next" src="img/fd.png" height="40px" width="40px" style="float: right;">
	</div>
	<?php include("menu.php"); ?>

	<div id="content">

	</div>

	<script type="text/javascript">
	var mois = <?php echo $mois; ?>;
	var annee = <?php echo $annee; ?>;
	var content = document.getElementById('content');
	var prev = document.getElementById('prev');
	var next = document.getElementById('next');

	function load(url, element){
	    req = new XMLHttpRequest();
	    req.open("GET", url, false);
	    req.send(null);

	    element.innerHTML = req.responseText; 
	}

	load( 'calendar.php?mois='+mois+'&annee='+annee+'',content);


	prev.addEventListener('click',function(){
		mois--;

		if(mois<1){
			annee--;
			mois=12;
		}

		load( 'calendar.php?mois='+mois+'&annee='+annee+'',content);
	});


	next.addEventListener('click',function(){
		mois++;

		if(mois>12){
			annee++;
			mois=1;
		}

		load( 'calendar.php?mois='+mois+'&annee='+annee+'',content);
	});
</script>






</body>
</html>