<?php

function calendrier($mois,$annee){
	try
			{
				$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
			}
			catch(Exception $e)
			{
			        die('Erreur : '.$e->getMessage());
			}
			$calendrier = $bdd->query('SELECT * FROM calendrier2');
			$donnees=$calendrier->fetch();
			
			function printEvent($date,$heure){
				$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
				$calendrier = $bdd->prepare('SELECT * FROM calendrier2 WHERE dates=? AND heure=?');
				$calendrier->execute(array($date, $heure));
				$donnees=$calendrier->fetch();
				if(is_array($donnees)){
					echo "<span style='font-family:Georgia;text-decoration:none;'>".$donnees['nom']."<br>";
				
					if($donnees['lieu']!=""){
						echo "Lieu : ".$donnees['lieu']."";
					}
					echo "</span>";
				}	
			}
	session_start();
	$id_session = $bdd->prepare('SELECT * FROM organisateur JOIN personne ON personne.id=organisateur.id WHERE personne.nom=? AND personne.prenom=?');
	$id_session -> execute(array($_SESSION['nom'],$_SESSION['prenom']));
	$donnees_session=$id_session->fetch();

	$nombre_de_jour = cal_days_in_month(CAL_GREGORIAN, $mois, $annee);
	echo "<table  style='background-color: white;''>";
	echo "<tr><th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th><th>Samedi</th><th>Dimanche</th></tr>";

	for ($i=1; $i <= $nombre_de_jour ; $i++) { 
		//on convertit les jours grégoriens en jours juliens
		$jour = cal_to_jd(CAL_GREGORIAN, $mois, $i, $annee);
		//on retourne le nombre de jours dans une semaine
		$jour_semaine = JDDayOfWeek($jour);

		if ($i==$nombre_de_jour) {
			if ($jour_semaine==1) { //si c'est le début de la semaine
				echo "<tr>";
			}
			echo "<td class='case'>";
			if(is_array($donnees_session)){
			if($donnees_session['id']!=""){
				echo "<a href='reservation.php?date=".construire_date($annee,$mois,$i)."';>";
			}}
			echo "<p style='background-color:grey; margin-top:0px;'>".$i."</p>";
			echo "<div>8h-10h<br> ";
			printEvent(construire_date($annee,$mois,$i),"8h-10h");
			echo "</div>";

			echo "<div>10h-12h<br> ";
			printEvent(construire_date($annee,$mois,$i),"10h-12h");
			echo "</div>";

			echo "<div>12h-14h<br> ";
			printEvent(construire_date($annee,$mois,$i),"12h-14h");
			echo "</div>";

			echo "<div>14h-16h<br> ";
			printEvent(construire_date($annee,$mois,$i),"14h-16h");
			echo "</div>";

			echo "<div>16h-18h<br> ";
			printEvent(construire_date($annee,$mois,$i),"16h-18h");
			echo "</d>";

			echo "<div>18h-20h<br> ";
			printEvent(construire_date($annee,$mois,$i),"18h-20h");
			echo "</div>";

			echo "<div>20h-23h<br> ";
			printEvent(construire_date($annee,$mois,$i),"20h-23h");
			echo "</div>";
			if(is_array($donnees_session)){
			if($donnees_session['id']!=""){
				echo "</a>";
			}}
			echo "</td></tr>";

		}
		elseif ($i==1) {
			echo "<tr>";
			if ($jour_semaine==0){ //le dimanche est associé au 0 en php
				$jour_semaine=7;
			}
			for ($k=1; $k !=$jour_semaine; $k++) {  //on avance jusqu'à tomber sur le bon jour par lequel le mois commence
				echo "<td></td>";
			}
			echo "<td class='case'>";
			if(is_array($donnees_session)){
			if($donnees_session['id']!=""){
				echo "<a href='reservation.php?date=".construire_date($annee,$mois,$i)."';>";
			}}
			echo "<p style='background-color:grey; margin-top:0px;'>".$i."</p>";
			echo "<div>8h-10h<br> ";
			printEvent(construire_date($annee,$mois,$i),"8h-10h");
			echo "</div>";

			echo "<div>10h-12h<br> ";
			printEvent(construire_date($annee,$mois,$i),"10h-12h");
			echo "</div>";

			echo "<div>12h-14h<br> ";
			printEvent(construire_date($annee,$mois,$i),"12h-14h");
			echo "</div>";

			echo "<div>14h-16h<br> ";
			printEvent(construire_date($annee,$mois,$i),"14h-16h");
			echo "</div>";

			echo "<div>16h-18h<br> ";
			printEvent(construire_date($annee,$mois,$i),"16h-18h");
			echo "</div>";

			echo "<div>18h-20h<br> ";
			printEvent(construire_date($annee,$mois,$i),"18h-20h");
			echo "</div>";

			echo "<div>20h-23h<br> ";
			printEvent(construire_date($annee,$mois,$i),"20h-23h");
			echo "</div>";
			if(is_array($donnees_session)){
			if($donnees_session['id']!=""){
				echo "</a>";
			}}
			echo "</td>";
			if ($jour_semaine==7){
				echo "</tr>";
			}
		}
		else{
			if($jour_semaine==1){
				echo "<tr>";
			}
			echo "<td class='case'>";
			if(is_array($donnees_session)){
			if($donnees_session['id']!=""){
				echo "<a href='reservation.php?date=".construire_date($annee,$mois,$i)."';>";
			}}
			echo "<p style='background-color:grey; margin-top:0px;'>".$i."</p>";
			echo "<div>8h-10h<br> ";
			printEvent(construire_date($annee,$mois,$i),"8h-10h");
			echo "</div>";

			echo "<div>10h-12h<br> ";
			printEvent(construire_date($annee,$mois,$i),"10h-12h");
			echo "</div>";

			echo "<div>12h-14h<br> ";
			printEvent(construire_date($annee,$mois,$i),"12h-14h");
			echo "</div>";

			echo "<div>14h-16h<br> ";
			printEvent(construire_date($annee,$mois,$i),"14h-16h");
			echo "</div>";

			echo "<div>16h-18h<br> ";
			printEvent(construire_date($annee,$mois,$i),"16h-18h");
			echo "</div>";

			echo "<div>18h-20h<br> ";
			printEvent(construire_date($annee,$mois,$i),"18h-20h");
			echo "</div>";

			echo "<div>20h-23h<br> ";
			printEvent(construire_date($annee,$mois,$i),"20h-23h");
			echo "</div>";

			if(is_array($donnees_session)){
			if($donnees_session['id']!=""){
				echo "</a>";
			}}
			echo "</td>";
			if($jour_semaine==0){
				echo "</tr>";
			}
		}
	}

	echo "</table>";
}

function afficher_jour_en_lettre($jour_semaine){
	$table = array('Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi');
	return $table[$jour_semaine];
}

function construire_date($annee,$mois,$jour){
		if($mois<10){
				if ($jour<10) {
					return $annee.'-0'.$mois.'-0'.$jour;
				}
				else{
					return $annee.'-0'.$mois.'-'.$jour;
				}
		}
		else{
			if ($jour<10) {
					return $annee.'-'.$mois.'-0'.$jour;
				}
				else{
					return $annee.'-'.$mois.'-'.$jour;
				}
		}
}

function afficher_mois_en_lettres($d){
	$correspondre = $d;
	$table = array('Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre');
	return $table[$correspondre-1];
}

?>