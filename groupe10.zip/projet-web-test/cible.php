<?php

	if(isset($_POST['deconnexion'])){
		session_start();
		$_SESSION = array();
		session_destroy();
		header("Location:index.php");
	}
	
	if(isset($_POST['pseudo']) AND isset($_POST['password']) AND isset($_POST['connexion'])){
		
		$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8' , 'root' , '');
		$personne = $bdd->prepare('SELECT nom,prenom FROM personne WHERE pseudo = ? AND password=? ');
		$personne->execute(array(htmlspecialchars($_POST['pseudo']),htmlspecialchars($_POST['password'])));
		$donnees=$personne->fetch();
        if(is_array($donnees)){
		if($donnees['nom']!="" AND $donnees['prenom']!=""){
			session_start();
			$_SESSION['nom']=$donnees['nom'];
			$_SESSION['prenom']=$donnees['prenom'];
			header("Location:index2.php");

		}
        }
		else{
			echo "<span style='color:white;'>Erreur d'authentification</span>";

		}

	}
?>