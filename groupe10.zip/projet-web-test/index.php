<?php
session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Football Manager - Accueil</title>
    <meta charset="utf-8">
    
    <!-- import the webpage's stylesheet -->
    <link rel="stylesheet" href="style.css">
    
  </head>
  
  
  <body>    
   
    <header id="header">
        <h1>Football Manager 2020</h1>
    </header>
    <?php include("formulaire.php"); ?>
    
    
  </body>
</html>
