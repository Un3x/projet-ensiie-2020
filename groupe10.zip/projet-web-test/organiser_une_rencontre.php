<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Réservation</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="index_calendrier.css">
</head>
<body>

	<?php
			try{
				$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
			}
			catch(Exception $e){
			        die('Erreur : '.$e->getMessage());
			}
			$calendrier = $bdd->query('SELECT * FROM calendrier2');
			$donnees=$calendrier->fetch();
			
			function printEvent($date,$heure){
				$bdd = new PDO('mysql:host=localhost;dbname=cours;charset=utf8', 'root', '');
				$calendrier = $bdd->prepare('SELECT * FROM calendrier2 WHERE dates=? AND heure=?');
				$calendrier->execute(array($date, $heure));
				$donnees=$calendrier->fetch();
				if(is_array($donnees)){
					echo "<span style='margin-left:2em;text-decoration:none'>".$donnees['nom']."";
					if($donnees['lieu']!=""){
						echo ". L'événement aura lieu à ".$donnees['lieu']."";
					} 
					echo "</span>";
				}
			}
			include 'menu.php';
	?>

	<h1>Bienvenue sur la page de réservation</h1>

	<?php
		$id_res = $bdd->prepare('SELECT * FROM organisateur JOIN personne ON personne.id=organisateur.id WHERE personne.nom=? AND personne.prenom=?');
		$id_res-> execute(array($_SESSION['nom'],$_SESSION['prenom']));
		$donnees_res=$id_res->fetch();
		if(is_array($donnees_res)){
		if($donnees_res['id']==""){
				echo "<h2>Vous n'êtes pas un organisateur, vous ne pouvez pas réserver de date. Communiquez avec votre coach pour qu'il réserve lui-même un événement</h2>";
		}
		else{
			echo "<div id='reservation' style='margin-bottom: 2em;''>
			<img src='img/fg2.jpg' style='float: left;' id='before2'>
		<img src='img/fd2.jpg' style='float: right;' id='next2'>
						<p style='text-align: center;''>";
				function afficher_mois_en_lettres($d){
					$correspondre = $d;
					$table = array('Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre');
					return $table[$correspondre-1];
				}

				function isValid($date, $format = 'Y-m-d'){
				    $dt = DateTime::createFromFormat($format, $date);
				    return $dt && $dt->format($format) === $date;
				  }
				if(isset($_GET['date']) AND isValid($_GET['date']) ){

					list($Y,$m,$d)=explode("-",$_GET['date']);
					echo $d.' ';
					echo afficher_mois_en_lettres($m);
					echo ' '. $Y;
					echo "</p>
					<hr>
					<p style='margin-left: 2em;'>8h-10h "; echo printEvent($_GET['date'],'8h-10h')."</p>
					<hr>
					<p style='margin-left: 2em;'>10h-12h "; echo printEvent($_GET['date'],'10h-12h')."</p>
					<hr>
					<p style='margin-left: 2em;'>12h-14h "; echo printEvent($_GET['date'],'12h-14h')."</p>
					<hr>
					<p style='margin-left: 2em;'>14h-16h "; echo printEvent($_GET['date'],'14h-16h')."</p>
					<hr>
					<p style='margin-left: 2em;'>16h-18h "; echo printEvent($_GET['date'],'16h-18h')."</p>
					<hr>
					<p style='margin-left: 2em;'>18h-20h "; echo printEvent($_GET['date'],'18h-20h')."</p>
					<hr>
					<p style='margin-left: 2em;'>20h-23h "; echo printEvent($_GET['date'],'20h-23h')."</p>
				</div>

				<form method='post' action=organiser_une_rencontre.php?date=".$_GET['date'].">
					<label for='hours'>Sélectionner l'horaire voulu</label>
					<select name='hours' id='hours' >
						<option>8h-10h</option>
						<option>10h-12h</option>
						<option>12h-14h</option>
						<option>14h-16h</option>
						<option>16h-18h</option>
						<option>18h-20h</option>
						<option>20h-23h</option>
					</select>
					<label for='event'>Quel événement voulez-vous ajouter au calendrier ?</label>
					<input type='text' name='event' id='event'>
					<label for='lieu'>Entrez le lieu de l'événement</label>
					<input type='text' name='lieu'>";
				$id_session = $bdd->prepare('SELECT * FROM organisateur JOIN personne ON personne.id=organisateur.id WHERE personne.nom=? AND personne.prenom=?');
				$id_session -> execute(array($_SESSION['nom'],$_SESSION['prenom']));
				$donnees_session=$id_session->fetch();

				echo "<input type='submit' name='submit' value='Ajouter au calendrier' id='ajouter'><br>";
					echo "<label for='supprimer'>Vous pouvez aussi choisir de supprimer l'événement pour l'horaire choisi</label>
					<input type='submit' value='Supprimer' name='supprimer'>";
			echo "</form>";
		}
	
			else{
					echo "<p>La faille SQLi, abréviation de SQL Injection, soit injection SQL en français, est un groupe de méthodes d'exploitation de faille de sécurité d'une application interagissant avec une base de données. Elle permet d'injecter dans la requête SQL en cours un morceau de requête non prévu par le système et pouvant en compromettre la sécurité. Ce site n'a pas cette faille.</p>";
				}
			}}
			?>



<?php 

	if(isset($_POST['supprimer'])){
				$calendrier_delete = $bdd->prepare('SELECT * FROM calendrier2 WHERE dates=? AND heure=?');
				$calendrier_delete->execute(array($_GET['date'], $_POST['hours']));
				$donnees_delete=$calendrier_delete->fetch();

				if($donnees_session['id']==$donnees_delete['id_organisateur']){
						$suppression = $bdd->prepare('DELETE FROM calendrier2 WHERE dates=? AND heure=?');
						$suppression ->execute(array($_GET['date'], $_POST['hours']));
				}
				else{
					echo "<p style='text-align:center;color:white;'>Vous n'êtes pas l'organisateur de cet événement, vous ne pouvez pas le supprimer.</p>";
				}
	}

	if(isset($_POST['submit']) AND isset($_POST['hours']) AND isset($_POST['event'])) {

			$req = $bdd->prepare('SELECT * FROM calendrier2 WHERE dates = ? AND heure = ?');
			$req->execute(array($_GET['date'], $_POST['hours']));
			$donnees = $req -> fetch();

	if($donnees['nom']==NULL){
				$request = $bdd->prepare('INSERT INTO calendrier2(dates, nom, heure, id_organisateur, lieu) VALUES( :dates, :nom, :heure, :id_organisateur,:lieu)');
				$request->execute(array(
				'dates' => $_GET['date'],
				'nom' => $_POST['event'],
				'heure' => $_POST['hours'],
				'id_organisateur' => $donnees_session['id'],
				'lieu' => $_POST['lieu']
				));
				header('Location: organiser_une_rencontre.php?date='.$_GET['date'].'');
			}
			else{
				echo "<p style='text-align:center;color:white;'>Un événement est déjà réservé à cette date</p>";
			}

}
		else{
			if($donnees_res['id']!=""){
			echo "<p style='text-align:center;color:white'>Veuillez sélectionner un horaire et remplir tous les champs</p>";
		}
		}

		?>


<script type="text/javascript">

	const event = document.getElementById('event'); 
	const ajouter = document.getElementById('ajouter');
	const jour = document.getElementById('jour');
	const hours = document.getElementById('hours');
	var horaires = document.getElementsByClassName("jour_semaine_8");
	
	//fonction permettant un raffraichissement de la page
	function load2(url,content){
	    req = new XMLHttpRequest();
	    req.open("GET", url, false);
	    req.send(null);
	    element.innerHTML = req.responseText; 
	}

	var mois = <?php echo $m; ?>;
	var annee = <?php echo $Y; ?>;
	var day = <?php echo $d ?>;

	var before2 = document.getElementById('before2');
	var next2 = document.getElementById('next2');
	var element=document.getElementById('reservation');
	var nombre_de_jour = <?php echo cal_days_in_month(CAL_GREGORIAN, $m, $Y); ?>;


	before2.addEventListener('click',function(){
		day--;
		if(day<1){
			mois--;
			<?php $m=$m-1; ?>
			day=<?php echo cal_days_in_month(CAL_GREGORIAN, $m, $Y); ?>;
		}

		if(mois<1){
			annee--;
			mois=12;
		}
		if(mois<10){
			if(day<10){
				document.location.href='organiser_une_rencontre.php?date='+annee+'-0'+mois+'-0'+day; 
			}
			else{
				document.location.href='organiser_une_rencontre.php?date='+annee+'-0'+mois+'-'+day; 
			}
		}
		else{
			if(day<10){
				document.location.href='organiser_une_rencontre.php?date='+annee+'-'+mois+'-0'+day; 
			}
			else{
				document.location.href='organiser_une_rencontre.php?date='+annee+'-'+mois+'-'+day; 
			}
		}
	});


	next2.addEventListener('click',function(){
		day++;
		if(day >= <?php echo cal_days_in_month(CAL_GREGORIAN, $m, $Y); ?>){
			mois++;
			<?php $m=$m+1;?>
			day=1;
		}
		if(mois>12){
			annee++;
			mois=1;
		}
		if(mois<10){
			if(day<10){
				document.location.href='organiser_une_rencontre.php?date='+annee+'-0'+mois+'-0'+day; 
			}
			else{
				document.location.href='organiser_une_rencontre.php?date='+annee+'-0'+mois+'-'+day; 
			}
		}
		else{
			if(day<10){
				document.location.href='organiser_une_rencontre.php?date='+annee+'-'+mois+'-0'+day; 
			}
			else{
				document.location.href='organiser_une_rencontre.php?date='+annee+'-'+mois+'-'+day; 
			}
		}
	});

</script>







</body>
</html>