<div id="connexion">
	<form action="cible.php" method="post">
		<div class="connect">
			<label for="pseudo">Nom d'utilisateur :</label>
			<input type="text" name="pseudo" id="pseudo" onfocusout="check()">
		</div>
		<div class=connect>
			<label for="password">Mot de passe :</label>
			<input type="password" name="password" id="password" onfocusout="check()">
		</div>
		<div class="connect">
		<input type="submit" value="Connexion" id="submit" name="connexion" disabled="true"> 
		<input type="submit" value="Deconnexion" id="deconnexion" name="deconnexion">
		<input type="button" name="inscription" value="Inscription" onclick="window.location.href = 'inscription.php';">
	</div>
	</form>
	<a href="inscription.php" id="inscription">Pas encore de compte ? <br/> Inscrivez-vous</a>
</div>

<script type="text/javascript">
	var pseudo = document.getElementById('pseudo');
	var password = document.getElementById('password');
	var connexion = document.getElementById('submit');

	function check(){
		if(pseudo.value!="" && password.value!="" ){
			connexion.removeAttribute('disabled');
		}
		else{
			connexion.setAttribute('disabled','true');
		}
}

</script>