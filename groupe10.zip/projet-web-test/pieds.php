<footer>
      <p>
        Copyright Football Manager - Tous droits réservés <br />
        <a href="mailto:paul.charnoz@ensiie.fr">Nous contacter</a>
        <a href="qui_sommes_nous.html">Qui sommes-nous</a>
      </p>
</footer>