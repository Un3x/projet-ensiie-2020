<?php

$mois = $_GET['mois'];
$annee = $_GET['annee'];
include('opti.php');
?>
<h1><?php echo afficher_mois_en_lettres($mois)." ".$annee ?></h1>
<div>
	<?php
	calendrier($mois,$annee); ?>
</div>