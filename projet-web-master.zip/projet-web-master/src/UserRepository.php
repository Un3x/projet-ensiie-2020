<?php

namespace User;

include '../src/User.php';

use DateTime;
use Exception;
use Interest\Interest;
use PDO;

class UserRepository
{
    /**
     * @var PDO
     */
    private $dbAdapter;

    public function __construct(PDO $dbAdapter)
    {
        $this->dbAdapter = $dbAdapter;
    }

    public function fetchAll()
    {
        $usersData = $this->dbAdapter->query('SELECT * FROM "user"');
        $users = [];
        foreach ($usersData as $usersDatum) {
            $user = new User();
            try {
                $user
                    ->setUsername($usersDatum['username'])
                    ->setPassword($usersDatum['password'])
                    ->setEmail($usersDatum['email'])
                    ->setCreatedAt(new DateTime($usersDatum['created_at']))
                    ->setAdmin($usersDatum['admin']);
            } catch (Exception $e) {
            }
            $users[] = $user;
        }
        return $users;
    }

    public function delete($username)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('DELETE FROM "user" where username = :username');

        $stmt->bindParam('username', $username);
        $stmt->execute();
    }

    public function follow($userfollowing, $userfollowed)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('INSERT INTO "Follow" (followed,following) VALUES (:userfollowed,:userfollowing) ');
        $stmt->bindParam('userfollowed', $userfollowed);
        $stmt->bindParam('userfollowing', $userfollowing);
        $stmt->execute();
        $stmt = $this
            ->dbAdapter
            ->prepare('UPDATE "user" SET followers = followers + 1 WHERE username=:userfollowed');
        $stmt->bindParam('userfollowed', $userfollowed);
        $stmt->execute();
    }

    public function unfollow($userfollowing, $userfollowed)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('DELETE FROM "Follow" where followed = :userfollowed and following = :userfollowing ');
        $stmt->bindParam('userfollowed', $userfollowed);
        $stmt->bindParam('userfollowing', $userfollowing);
        $stmt->execute();
        $stmt = $this
            ->dbAdapter
            ->prepare('UPDATE "user" SET followers = followers - 1 WHERE username=:userfollowed');
        $stmt->bindParam('userfollowed', $userfollowed);
        $stmt->execute();
    }

    public
    function fetchfollowers($username)
    {
        $usersData = $this->dbAdapter->prepare('SELECT username,password,admin,email,created_at FROM "user" JOIN "Follow" ON username = following where :username=followed');
        $usersData->bindParam('username', $username);
        $usersData->execute();
        $users = [];
        foreach ($usersData as $usersDatum) {
            $user = new User();
            try {
                $user
                    ->setUsername($usersDatum['username'])
                    ->setPassword($usersDatum['password'])
                    ->setEmail($usersDatum['email'])
                    ->setCreatedAt(new DateTime($usersDatum['created_at']))
                    ->setAdmin($usersDatum['admin']);
            } catch (Exception $e) {
            }
            $users[] = $user;
        }
        return $users;
    }

    public function register($username, $password, $email)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('INSERT INTO "user" (username,password,email,Followers,created_at) VALUES (:username,:password, :email,0,NOW()) ');
        $stmt->bindParam('username', $username);
        $stmt->bindParam('email', $email);
        $stmt->bindParam('password', $password);
        $stmt->execute();
    }

    public function fetchinterests($username)
    {
        $interestsData = $this->dbAdapter->prepare('SELECT theme FROM "Interested" WHERE username=:username');
        $interestsData->bindParam('username', $username);
        $interestsData->execute();
        $interests = [];
        foreach ($interestsData as $interestsDatum) {
            $interest = new Interest();
            try {
                $interest
                    ->setTheme($interestsDatum['theme'])
                    ->setSubscribers($interestsDatum['subscribers']);
            } catch (Exception $e) {
            }
            $interests[] = $interest;
        }
        return $interests;
    }

    public function fetchUser($username)
    {
        $usersData = $this->dbAdapter->prepare('SELECT * FROM "user" WHERE username=:username');
        $usersData->bindParam('username', $username);
        $usersData->execute();
        $users = [];
        foreach ($usersData as $usersDatum) {
            $user = new User();
            try {
                $user
                    ->setUsername($usersDatum['username'])
                    ->setPassword($usersDatum['password'])
                    ->setEmail($usersDatum['email'])
                    ->setCreatedAt(new DateTime($usersDatum['created_at']))
                    ->setAdmin($usersDatum['admin']);
            } catch (Exception $e) {
            }
            $users[] = $user;
        }
        return $users;
    }

    public function userCanLog($username, $password)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('SELECT * FROM "user" WHERE username=:username AND password=:password');
        $stmt->bindParam('username', $username);
        $stmt->bindParam('password', $password);
        $stmt->execute();
        $count = 0;
        foreach ($stmt as $user) {
            $count += 1;
        }
        if ($count == 0) {
            return false;
        }
        return true;
    }

    public function userExists($username)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('SELECT * FROM "user" WHERE username=:username');
        $stmt->bindParam('username', $username);
        $stmt->execute();
        $count = 0;
        foreach ($stmt as $user) {
            $count += 1;
        }
        if ($count == 0) {
            return false;
        }
        return true;
    }

    public function addInterested($username, $Pref)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('INSERT INTO "Interested" (username,theme) VALUES (:user,:pref)');
        foreach ($Pref as $name) {
            $stmt->bindParam('user', $username);
            $stmt->bindParam('pref', $name);
            $stmt->execute();
        }
    }

    public function addPost($username, $content)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('INSERT INTO "Post" (author, content, created_at) VALUES (:user,:content,NOW())');
        $stmt->bindParam('user', $username);
        $stmt->bindParam('content', $content);
        $stmt->execute();

    }

    public function SetPref($username, $Pref)
    {
        $stmt = $this
            ->dbAdapter
            ->prepare('INSERT INTO "Interested" (username, theme) VALUES (:user,:pref)');
        foreach ($Pref as $name) {
            $stmt->bindParam('user', $username);
            $stmt->bindParam('pref', $name);
            $stmt->execute();
        }
    }
}
