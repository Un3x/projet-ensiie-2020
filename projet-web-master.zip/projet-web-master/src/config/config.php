<?php

return [
    'db' => [
        'host' => 'localhost',
        'user' => 'ensiie',
        'password' => 'ensiie',
        'dbname' => 'ensiie'
    ]
];
