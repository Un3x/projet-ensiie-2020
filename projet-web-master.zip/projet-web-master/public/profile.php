<?php session_start();
$username = $_SESSION['username'];
$email = $_SESSION['email'];
?>

<html lang="">
<head>
    <title>Twittiie</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
    <link rel="stylesheet" href="assets/css/profile.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>


<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Projet Web Ensiie 2020 : Twittiie</a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="/">Home</a>
                </li>
                <li>
                    <a class="nav-link" href="/signup.php">Sign up</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<div class="profile">

    <?php if (isset($username)) {
        echo ' <h1>Hello ' . $username . ' !</h1> ';
    } ?>
    <?php if (isset($email)) {
        echo '<p class="title">e-mail:' . $email . '</p>';
    }
    ?>
    <p>Intérêts:</p>
    <a href="#"><i class="fa fa-dribbble"></i></a>
    <a href="#"><i class="fa fa-twitter"></i></a>
    <a href="#"><i class="fa fa-linkedin"></i></a>
    <a href="#"><i class="fa fa-facebook"></i></a>
    <p>
        <button class="contact">Contact</button>
    </p>
    <img src="images/me.jpg" alt="John" style="width:100%">
</div>
<div method=POST class="comment" style="padding-top: 20px">
    <h3>Vos Messages</h3>
    <p>
        <label>
            <input type="text" id="post" class="message" style="width: 400px;" placeholder="Dites ce que vous avez en tête !">
        </label></p>
    <p>
        <button type="submit" style="position: relative;" class="confirm" onclick="post(); return false;">Poster</button>
    </p>
</div>
<script src="scripts.js"></script>
</body>
