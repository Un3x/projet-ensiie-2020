<?php
use User\UserRepository;

include '../src/User.php';
include '../src/UserRepository.php';
include '../src/Factory/DbAdaperFactory.php';
$dbAdaper = (new DbAdaperFactory())->createService();
$userRepository = new UserRepository($dbAdaper);
$user=$_SESSION['username']?? null;
$Pref = $_REQUEST['Pref']?? null;
$userRepository->addInterested($user,$Pref)

?>