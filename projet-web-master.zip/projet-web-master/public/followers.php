<?php

use User\UserRepository;


include '../src/UserRepository.php';
include '../src/Factory/DbAdaperFactory.php';
$dbAdaper = (new DbAdaperFactory())->createService();
$userRepository = new UserRepository($dbAdaper);
$username = $_REQUEST['username']?? null;
$users = $userRepository->fetchfollowers($username) ?? null;
echo "<div class=\"col-sm-12\">
        <table cellspacing=”10″ cellpadding=”10″ table-layout=\"auto\" width=100%>
            <tr>
                <th>username</th>
                <th>email</th>
            </tr>\n";
foreach ($users as $user): echo "
                <tr>
                    <td> {$user->getUsername()}</td>
                    <td> {$user->getEmail()}</td>
                </tr>";
endforeach;
 echo "       </table>
    </div>";
