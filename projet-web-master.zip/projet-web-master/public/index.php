<!DOCTYPE HTML>
<?php

use User\UserRepository;

include '../src/UserRepository.php';
include '../src/Factory/DbAdaperFactory.php';
session_start();
$dbAdaper = (new DbAdaperFactory())->createService();
$userRepository = new UserRepository($dbAdaper);
$users = $userRepository->fetchAll();

?>
<html lang="fr">
<head>
    <title>Twittiie</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
    <link rel="stylesheet" href="assets/css/main.css"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <noscript>
        <link rel="stylesheet" href="assets/css/noscript.css"/>
    </noscript>
</head>
<body class="is-preload">
<h1 class="display-4">Connect to all your friends !</h1>
<!-- Wrapper-->
<div id="wrapper">

    <!-- Nav -->
    <nav id="nav">
        <a href="#" class="icon solid fa-home"><span>Home</span></a>
        <a href="#work" class="icon solid fa-folder"><span>Work</span></a>
        <a href="#contact" class="icon solid fa-envelope"><span>Contact</span></a>
        <a href="https://twitter.com" class="icon brands fa-twitter"><span>Twitter</span></a>
    </nav>

    <!-- Main -->
    <div id="main">

        <!-- Me -->
        <article id="home" class="panel intro">
            <header>
                <?php if (isset($_SESSION['username'])) : ?>
                <h1><a href="profile.php">Your profile</a></h1>
                <?php else : ?>
                <h1><a href="Authentification.php">Connectez-vous</a></h1>
                <?php endif; ?>
                <p>What you're doing in life</p>
            </header>
            <a href="#work" class="jumplink pic">
                <span class="arrow icon solid fa-chevron-right"><span>See my work</span></span>
                <img src="images/me.jpg" alt=""/>
            </a>
        </article>

        <!-- Work -->
        <article id="work" class="panel">
            <header>
                <h2>Centers of interest</h2>
            </header>
            <p>
                Phasellus enim sapien, blandit ullamcorper elementum eu, condimentum eu elit.
                Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia
                luctus elit eget interdum.
            </p>
            <section>
                <div class="row">
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic01.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic02.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic03.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic04.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic05.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic06.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic07.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic08.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic09.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic10.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic11.jpg" alt=""></a>
                    </div>
                    <div class="col-4 col-6-medium col-12-small">
                        <a href="#" class="image fit"><img src="images/pic12.jpg" alt=""></a>
                    </div>
                </div>
            </section>
        </article>

        <!-- Contact -->
        <article id="contact" class="panel">
            <header>
                <h2>Contact your friends registered on Twittiie !</h2>
            </header>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <ul class="nav">
                    <?php if (!isset($_SESSION['username'])) : ?>
                    <li>

                        <a class="nav-link" href="/signup.php">Sign up now !</a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <?php if (isset($_SESSION['username'])) : ?>
                        <a class="nav-link" href="/index.php" onclick="disconnect(); return false;">Disconnect</a>
                        <?php else : ?>
                        <a class="nav-link" href="/Authentification.php">Already have an account ? Log in!</a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <a class="nav-link" href="/Trends.html">Current Trends to follow</a>
                    </li>
                </ul>
            </nav>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <h1>Tons of new people to meet:</h1>
                    </div>
                    <div class="col-sm-12">
                        <table class="table">
                            <thead class="thead-dark">
                            <tr>
                                <th scope="col" style="text-align: center">username</th>
                                <th scope="col" style="text-align: center">email</th>
                                <th scope="col" style="text-align: center">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr <?php echo "id=\"user";
                                echo $user->getUsername();
                                echo "\"" ?>>
                                    <th scope="row" style="text-align: center"><?= $user->getUsername() ?></th>
                                    <td style="text-align: center" ><?= $user->getEmail() ?></td>
                                    <td style="text-align: center">
                                        <table class="table table-borderless" >
                                            <thead >
                                            <tr>
                                                <?php if (isset($_SESSION['admin']) && $_SESSION['admin']) : ?>
                                                    <th>
                                                        <button value="<?= $user->getUsername() ?>"
                                                                onclick="deleteuser(this.value); return false;">
                                                            Delete
                                                        </button>
                                                    </th>
                                                    <?php endif
                                                ?>
                                                <th>
                                                    <?php if (isset($_SESSION['username'])) : ?>

                                                        <button value="<?= $user->getUsername() ?>"
                                                                onclick="followorunfollow(this.value); return false;">
                                                            Follow
                                                        </button>
                                                    <?php else : ?>
                                                        <button value="<?= $user->getUsername() ?>"
                                                                onclick="no_user('follow',this.value); return false;">
                                                            Follow
                                                        </button>
                                                    <?php endif ?>
                                                    <div <?php echo "id=\"follows";
                                                    echo $user->getUsername();
                                                    echo "\"" ?> style="position: absolute;"></div>
                                                </th>
                                                <th>
                                                    <button value="<?= $user->getUsername() ?>"
                                                            onclick="showfollowers(this.value); return false;">Followers
                                                    </button>
                                                    <div <?php echo "id=\"followers";
                                                    echo $user->getUsername();
                                                    echo "\"" ?> style="position: relative;"></div>
                                                </th>
                                            </tr>
                                            </thead>
                                        </table>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                    </div>
                </div>
            </div>

        </article>
    </div>


    <div id="footer">
        <ul class="copyright">
            <li>&copy; ENSIIE</li>
            <li>Design: ENSIIE</li>
        </ul>
    </div>

</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
<script src="scripts.js"></script>


</body>
</html>