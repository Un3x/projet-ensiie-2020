<?php

use User\UserRepository;

include '../src/UserRepository.php';
include '../src/Factory/DbAdaperFactory.php';
session_start();
$dbAdaper = (new DbAdaperFactory())->createService();
$userRepository = new UserRepository($dbAdaper);
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
if ($userRepository->userCanLog($username, $password)) {
    $users = $userRepository->fetchUser($username);
    foreach ($users as $user){
        $_SESSION['username'] = $user->getUsername();
        $_SESSION['email'] = $user->getEmail();
        $_SESSION['admin'] = $user->getAdmin();
    }
    echo 1;
} else {
    echo 0;
}
